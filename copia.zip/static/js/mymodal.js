$(function(){
    $('#my_modal_runner').DjangoModalRunner();
});