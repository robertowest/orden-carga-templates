from django.apps import AppConfig


class PersonConfig(AppConfig):
    name = 'person'
