from django_modalview.generic.base import ModalTemplateView
from django.views.generic import ListView, CreateView, UpdateView

from .models import Person
from .forms import PersonForm


class MyModal(ModalTemplateView):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.title = "My modal"
        self.description = "This is my description"
        self.icon = "icon-mymodal"


class PersonListView(ListView):
    model = Person


class PersonCreateView(CreateView):
    model = Person
    fields = ('name', 'email', 'job_title', 'bio')


class PersonUpdateView(UpdateView):
    model = Person
    form_class = PersonForm
    template_name = 'people/person_update_form.html'