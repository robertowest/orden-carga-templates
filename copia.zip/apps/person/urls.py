from django.urls import path

from . import views

urlpatterns = [
    path('', views.MyModal.as_view(), name='person_list'),
    # path('', views.PersonListView.as_view(), name='person_list'),
    # path('add/', include('apps.person.urls'), name='person'),
    # path('edit/', include('apps.person.urls'), name='person'),
    # path('delete/', include('apps.person.urls'), name='person'),
]
