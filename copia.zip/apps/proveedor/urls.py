from django.urls import path

from apps.proveedor import views

app_name = "proveedor"

urlpatterns = [
    path('', views.ListadoProveedores.as_view(), name='show'),
    path('add/', views.CrearProveedor.as_view(), name='add'),
    path('edit/<int:pk>', views.ModificarProveedor.as_view(), name='edit'),
    path('delete/<int:pk>', views.DetalleProveedor.as_view(), name='delete'),
]
